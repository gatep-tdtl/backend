# File: gatep_platform_backend/auth_management/urls.py

from django.urls import path
from .views import RegisterView, LoginView, OTPVerificationView, resend_otp # CustomLogoutView is managed in main urls.py

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', LoginView.as_view(), name='login'),
    path('verify-otp/', OTPVerificationView.as_view(), name='verify-otp'),
    path('resend-otp/', resend_otp, name='resend-otp'),
]
