# File: gatep_platform_backend/auth_management/serializers.py

from django.contrib.auth import authenticate
from rest_framework import serializers
import re
from django.core.mail import send_mail
from django.conf import settings
from rest_framework import status

# IMPORTANT: Import CustomUser and UserRole from talent_management.models
from talent_management.models import CustomUser, UserRole, TalentProfile, EmployerProfile


class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)
    confirm_password = serializers.CharField(write_only=True)
    phone_number = serializers.CharField(max_length=20, required=False, allow_blank=True)

    # MODIFIED: Now includes ADMIN in the user_role choices for registration
    user_role = serializers.ChoiceField(
        choices=[
            (UserRole.ADMIN.value, UserRole.ADMIN.label),     # ADMIN role is now available
            (UserRole.TALENT.value, UserRole.TALENT.label),
            (UserRole.EMPLOYER.value, UserRole.EMPLOYER.label)
        ],
        required=True
    )

    class Meta:
        model = CustomUser
        fields = ('username', 'email', 'phone_number', 'password', 'confirm_password', 'user_role')
        extra_kwargs = {
            'password': {'write_only': True}
        }

    def validate(self, data):
        if data['password'] != data['confirm_password']:
            raise serializers.ValidationError({"confirm_password": "Passwords do not match."})

        if CustomUser.objects.filter(username=data['username']).exists():
            raise serializers.ValidationError({"username": "A user with that username already exists."})

        if CustomUser.objects.filter(email=data['email']).exists():
            raise serializers.ValidationError({"email": "A user with that email already exists."})

        if data.get('phone_number'):
            if CustomUser.objects.filter(phone_number=data['phone_number']).exists():
                raise serializers.ValidationError({"phone_number": "A user with that phone number already exists."})

        return data

    def validate_password(self, value):
        if len(value) < 8:
            raise serializers.ValidationError("Password must be at least 8 characters long.")
        if not re.search(r'[A-Z]', value):
            raise serializers.ValidationError("Password must contain at least one uppercase letter.")
        if not re.search(r'[a-z]', value):
            raise serializers.ValidationError("Password must contain at least one lowercase letter.")
        if not re.search(r'[0-9]', value):
            raise serializers.ValidationError("Password must contain at least one digit.")
        if not re.search(r'[!@#$%^&*()_+\-=\[\]{};:\'",.<>/?`~]', value):
            raise serializers.ValidationError("Password must contain at least one special character.")
        return value

    def create(self, validated_data):
        validated_data.pop('confirm_password')
        user_role = validated_data.pop('user_role')

        user = CustomUser.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            password=validated_data['password'],
            phone_number=validated_data.get('phone_number'),
            user_role=user_role,
            is_active=False
        )

        # Create role-specific profile based on user_role
        if user_role == UserRole.TALENT:
            TalentProfile.objects.create(user=user)
        elif user_role == UserRole.EMPLOYER:
            EmployerProfile.objects.create(user=user)
        # Note: Admin users do not have a separate profile model in this setup.
        # If you later decide to have an AdminProfile, you'd add creation logic here.

        otp = user.generate_otp()

        subject = 'Your OTP for Registration Verification'
        message = f'Hi {user.username},\n\nYour One-Time Password (OTP) for registration is: {otp}\n\nThis OTP is valid for 5 minutes.'
        from_email = settings.DEFAULT_FROM_EMAIL
        recipient_list = [user.email]
        try:
            send_mail(subject, message, from_email, recipient_list, fail_silently=False)
        except Exception as e:
            user.delete()
            print(f"Error sending OTP email to {user.email}: {e}")
            raise serializers.ValidationError(
                {'email': "Failed to send OTP email. Please ensure your email configuration is correct and try again."},
                code='email_send_failure'
            )

        return user


class LoginSerializer(serializers.Serializer):
    phone_or_email = serializers.CharField(required=True)
    password = serializers.CharField(write_only=True)

    def validate(self, data):
        phone_or_email = data.get('phone_or_email')
        password = data.get('password')

        user = None
        if phone_or_email and password:
            user = authenticate(username=phone_or_email, password=password)

            if not user and '@' in phone_or_email:
                try:
                    user_by_email = CustomUser.objects.get(email=phone_or_email)
                    user = authenticate(username=user_by_email.username, password=password)
                    if user and user.user_role not in [UserRole.TALENT.value, UserRole.EMPLOYER.value, UserRole.ADMIN.value]:
                        raise serializers.ValidationError('User role is invalid or not recognized.')
                except CustomUser.DoesNotExist:
                    pass

            if not user and not '@' in phone_or_email:
                try:
                    user_by_phone = CustomUser.objects.get(phone_number=phone_or_email)
                    user = authenticate(username=user_by_phone.username, password=password)
                    if user and user.user_role not in [UserRole.TALENT.value, UserRole.EMPLOYER.value, UserRole.ADMIN.value]:
                        raise serializers.ValidationError('User role is invalid or not recognized.')
                except CustomUser.DoesNotExist:
                    pass

            if not user:
                raise serializers.ValidationError('Invalid credentials.')
            if not user.is_active:
                raise serializers.ValidationError('Account not verified. Please verify your email.')
        else:
            raise serializers.ValidationError('Must include "phone_or_email" and "password".')

        data['user'] = user
        return data


class OTPVerificationSerializer(serializers.Serializer):
    username = serializers.CharField(required=True)
    otp = serializers.CharField(required=True, max_length=6)

    def validate(self, data):
        username = data.get('username')
        otp_received = data.get('otp')

        try:
            user = CustomUser.objects.get(username=username)
        except CustomUser.DoesNotExist:
            raise serializers.ValidationError({'username': 'Invalid username or user not found.'})

        if user.is_active:
            raise serializers.ValidationError({'message': 'Account already verified.'})

        if not user.otp or not user.otp_created_at:
            raise serializers.ValidationError({'otp': 'No OTP generated for this user. Please register again or request a new OTP.'})

        if not user.is_otp_valid():
            raise serializers.ValidationError({'otp': 'OTP has expired. Please request a new OTP.'})

        if user.otp != otp_received:
            raise serializers.ValidationError({'otp': 'Invalid OTP.'})

        data['user'] = user
        return data

