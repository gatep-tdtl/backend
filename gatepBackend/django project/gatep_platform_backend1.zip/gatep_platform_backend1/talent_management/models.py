# File: gatep_platform_backend/talent_management/models.py

from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils.translation import gettext_lazy as _
from django.utils import timezone
import random
import string

# Define choices for user roles - ONLY ADMIN, TALENT, EMPLOYER
class UserRole(models.TextChoices):
    ADMIN = 'ADMIN', _('Admin')
    TALENT = 'TALENT', _('Talent')               # Renamed from JOB_APPLICANT
    EMPLOYER = 'EMPLOYER', _('Employer')         # Renamed from HIRING_ORGANIZATION


class CustomUser(AbstractUser):
    email = models.EmailField(_('email address'), unique=True, blank=True)
    user_role = models.CharField(
        max_length=50,
        choices=UserRole.choices,
        default=UserRole.TALENT,                 # Default role for new registrations
        verbose_name=_('User Role')
    )
    # Boolean flags for role checks - ONLY is_talent_role, is_employer_role
    is_talent_role = models.BooleanField(default=True)
    is_employer_role = models.BooleanField(default=False)
    # is_employee_role is completely removed

    otp = models.CharField(max_length=6, blank=True, null=True)
    otp_created_at = models.DateTimeField(blank=True, null=True)
    phone_number = models.CharField(max_length=20, blank=True, null=True, unique=True)


    def generate_otp(self):
        """Generates a 6-digit numeric OTP and saves it with a timezone-aware timestamp."""
        self.otp = ''.join(random.choices(string.digits, k=6))
        self.otp_created_at = timezone.now()
        self.save()
        return self.otp

    def is_otp_valid(self):
        """Checks if the OTP is still valid (e.g., within a 5-minute window)."""
        if self.otp and self.otp_created_at:
            return (timezone.now() - self.otp_created_at) < timezone.timedelta(minutes=5)
        return False


    def save(self, *args, **kwargs):
        # Update boolean flags based on user_role before saving
        self.is_talent_role = (self.user_role == UserRole.TALENT)
        self.is_employer_role = (self.user_role == UserRole.EMPLOYER)
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.username} ({self.user_role})"


# Profile Models for Specific User Roles - ONLY TalentProfile and EmployerProfile
# EmployeeProfile class is completely removed
class TalentProfile(models.Model): # Renamed from JobApplicantProfile
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, primary_key=True)
    resume_url = models.URLField(blank=True, null=True)
    skills = models.TextField(blank=True, null=True)
    portfolio_url = models.URLField(blank=True, null=True)
    def __str__(self):
        return f'{self.user.username} (Talent Profile)'

class EmployerProfile(models.Model): # Renamed from HiringOrganizationProfile
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, primary_key=True)
    company_name = models.CharField(max_length=255)
    website_url = models.URLField(blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    industry = models.CharField(max_length=100, blank=True, null=True)
    def __str__(self):
        return f'{self.user.username} (Employer Profile - {self.company_name})'
